#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, csv, datetime as dt, json, time, sys, os
from pathlib import Path
import yaml
import tinytuya

try:
    import paho.mqtt.client as mqtt
except Exception:
    mqtt = None

def load_cfg(p):
    with open(p, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def mk_device(dev_cfg):
    d = tinytuya.Device(
        dev_cfg['id'], dev_cfg['ip'], dev_cfg['local_key'],
        version=dev_cfg.get('version', 3.4)
    )
    d.set_socketPersistent(True)
    return d

def ensure_csv(path, headers):
    newfile = not Path(path).exists() or os.path.getsize(path) == 0
    f = open(path, 'a', newline='')
    w = csv.writer(f)
    if newfile:
        w.writerow(['ts'] + headers)
        f.flush()
    return f, w

def mk_mqtt(mcfg):
    if not mcfg.get('enabled', False):
        return None, None
    if mqtt is None:
        print("[WARN] MQTT habilitado pero paho-mqtt no está instalado.", file=sys.stderr)
        return None, None
    client = mqtt.Client(client_id=mcfg.get('client_id','tuya8in1'))
    if mcfg.get('username'):
        client.username_pw_set(mcfg.get('username'), mcfg.get('password',''))
    client.connect(mcfg.get('host','localhost'), int(mcfg.get('port',1883)), 60)
    client.loop_start()
    return client, mcfg.get('topic','sensors/aquarium')

def convert(name, raw, scales):
    if raw is None: return None
    s = int(scales.get(name, 0))
    return raw / (10 ** s) if s > 0 else raw

def merge_dps(cache, new):
    """Devuelve un dict con últimos valores conocidos."""
    if not isinstance(new, dict): new = {}
    cache.update({k: v for k, v in new.items() if v is not None})
    return cache

def read_full_snapshot(dev, wanted_dp_ids, tries=3, delay=0.2):
    """Intenta juntar todos los DPs deseados con varios status()."""
    merged = {}
    for _ in range(max(1, tries)):
        try:
            s = dev.status()
            dps = s.get('dps', {}) or {}
            merged.update(dps)
            if all(dp in merged for dp in wanted_dp_ids):
                break
        except Exception as e:
            print("[WARN] status() fallo:", e, file=sys.stderr)
        time.sleep(delay)
    return merged

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config.yaml', help='Ruta a config.yaml')
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    dev_cfg = cfg['device']
    dp_map = cfg.get('dp_map', {})
    dp_scale = cfg.get('dp_scale', {})
    headers = list(dp_map.keys())
    csv_path = cfg.get('logging', {}).get('csv_path', 'aquarium_readings.csv')
    interval = float(cfg.get('poll', {}).get('interval_sec', 10))

    # Dispositivo y CSV
    d = mk_device(dev_cfg)
    f, w = ensure_csv(csv_path, headers)
    client, topic = mk_mqtt(cfg.get('mqtt', {}))

    # Cache de últimos DPs
    last = {}

    # Primer “snapshot” intentando cubrir todos los DPs mapeados
    wanted_dp_ids = set(dp_map.values())
    print(f"[i] Iniciando logger cada {interval}s. CSV: {csv_path}. DPs: {dp_map}")
    snap = read_full_snapshot(d, wanted_dp_ids, tries=4, delay=0.25)
    last = merge_dps(last, snap)

    try:
        while True:
            ts = dt.datetime.now().isoformat()
            try:
                s = d.status()
                dps_now = s.get('dps', {}) or {}
                last = merge_dps(last, dps_now)  # fusiona parcial -> estado completo

                # Construir fila con último valor conocido (sin huecos)
                row_vals = []
                payload = {}
                for name, dp in dp_map.items():
                    raw = last.get(dp)
                    val = convert(name, raw, dp_scale)
                    row_vals.append(val)
                    payload[name] = val

                w.writerow([ts] + row_vals); f.flush()

                if client and topic:
                    client.publish(topic, json.dumps(payload), qos=0, retain=False)

            except Exception as e:
                print("[ERR]", e, file=sys.stderr)

            time.sleep(interval)

    finally:
        try: f.close()
        except Exception: pass
        if client: client.loop_stop()

if __name__ == '__main__':
    sys.exit(main())
