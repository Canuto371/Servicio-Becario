#!/usr/bin/env python3
import tinytuya, time, yaml
cfg = yaml.safe_load(open("config.yaml"))
d = tinytuya.Device(cfg["device"]["id"], cfg["device"]["ip"], cfg["device"]["local_key"], version=cfg["device"].get("version",3.4))
d.set_socketPersistent(True)
last = {}
while True:
    s = d.status()
    dps = s.get("dps", {}) or {}
    for k in sorted(dps, key=lambda x:int(x)):
        if last.get(k) != dps[k]:
            print(f"[chg] DP {k}: {last.get(k)} -> {dps[k]}")
    last.update(dps)
    time.sleep(2)
