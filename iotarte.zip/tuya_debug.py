
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, json, time, sys
from pathlib import Path
import yaml
import tinytuya

def load_cfg(p):
    with open(p, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def mk_device(cfg, version=None):
    dev = cfg['device']
    ver = version or dev.get('version', 3.4)
    d = tinytuya.Device(dev['id'], dev['ip'], dev['local_key'], version=ver)
    d.set_socketPersistent(True)
    return d, ver

def try_status(d):
    return d.status()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config.yaml', help='Ruta a config.yaml')
    ap.add_argument('--interval', type=float, default=5.0, help='Segundos entre lecturas')
    ap.add_argument('--once', action='store_true', help='Lee una sola vez y termina')
    args = ap.parse_args()

    cfg = load_cfg(args.config)

    # Intento automático 3.4 -> 3.3 si falla
    for ver in (cfg['device'].get('version', 3.4), 3.3):
        try:
            d, v = mk_device(cfg, version=ver)
            s = try_status(d)
            print(f"Version probada: {v}")
            print(json.dumps(s, indent=2, ensure_ascii=False))
            if args.once:
                return 0
            break
        except Exception as e:
            print(f"[WARN] Falló con version={ver}: {e}", file=sys.stderr)
    else:
        print("[ERR] No se pudo leer status con 3.4 ni 3.3", file=sys.stderr)
        return 2

    while True:
        try:
            s = d.status()
            print(json.dumps(s, indent=2, ensure_ascii=False))
        except Exception as e:
            print("[ERR]", e, file=sys.stderr)
        time.sleep(args.interval)

if __name__ == '__main__':
    sys.exit(main())
